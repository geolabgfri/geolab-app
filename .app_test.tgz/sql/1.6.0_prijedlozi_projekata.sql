-- =============================================================
--  v1.6.0 — Prijedlozi projekata (osoba iz tablice osoblje predlaze,
--  voditelj/laborant odobrava na stranici Odobravanje)
--  Pokreni JEDNOM u Supabase -> SQL Editor -> Run.
--  Dodaje samo novu tablicu; postojece tablice se ne mijenjaju.
-- =============================================================

CREATE TABLE IF NOT EXISTS prijedlozi_projekata (
    id                  BIGSERIAL PRIMARY KEY,
    predlagatelj        TEXT NOT NULL,
    predlozena_oznaka   TEXT,
    naziv               TEXT NOT NULL,
    gradiliste          TEXT,
    opis                TEXT,
    klijent_id          BIGINT REFERENCES klijenti(id),
    novi_klijent_naziv  TEXT,
    novi_klijent_tip    TEXT CHECK (novi_klijent_tip IN ('komercijalni','interni')),
    status              TEXT NOT NULL DEFAULT 'na_cekanju'
                        CHECK (status IN ('na_cekanju','odobreno','odbijeno')),
    vrijeme_prijave     TIMESTAMPTZ NOT NULL DEFAULT now(),
    odobrio             TEXT,
    datum_odobrenja     TIMESTAMPTZ,
    napomena_odluke     TEXT,
    projekt_id          BIGINT REFERENCES projekti(id),
    CHECK (klijent_id IS NOT NULL OR novi_klijent_naziv IS NOT NULL)
);

CREATE INDEX IF NOT EXISTS prijedlozi_projekata_status_idx
    ON prijedlozi_projekata (status);

-- Aplikacija se spaja kao 'postgres' pa RLS ne smeta; javni API ostaje zatvoren.
ALTER TABLE prijedlozi_projekata ENABLE ROW LEVEL SECURITY;
